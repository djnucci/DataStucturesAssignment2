Assignment 2

- All inputs are from the console, you can enter them in when prompted. remember to have the full file path when entering it.
- For selecting the type of search enter dfs, bfs, path or cycle (not case sensitive) and the ouptu should tell you the ordered list or that no such path exists
- 